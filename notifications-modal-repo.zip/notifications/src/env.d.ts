declare module "*.vue" { import type { DefineComponent } from "vue"; const c: DefineComponent; export default c }
